Demo 

1.For the demo, the player can only make one move
2.Some move validation is not check, player can actually place a piece on the position where all 8 surrounding block is BLANK. I will fix that later



For The Final Code
1. Comment for similar codes only write once. For example, check direction.

