#ifndef REVERSI_H
#define REVERSI_H

#include "game.h"

#endif
